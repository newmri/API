#pragma once
#include "Common.h"

#define MAX_NUM 1000

void ShowMultipleResult(void); // Question 1

