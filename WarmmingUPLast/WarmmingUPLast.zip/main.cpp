#include "MainSelect.h"

#define MAX_QUESTION 12

int main()
{
	bool roop = true;
	while (roop) roop=MainSelect();

}