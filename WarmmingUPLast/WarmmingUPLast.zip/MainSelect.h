#pragma once

#include "ExceptionHandling.h"
#include "Questions.h"
#include "Question2.h"
#include "Question3.h"
#include "Question4.h"
#include "Question5.h"
#include "Question7.h"

bool MainSelect();