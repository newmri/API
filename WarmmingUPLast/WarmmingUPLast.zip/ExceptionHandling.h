#pragma once
#include "Common.h"

bool ExceptionHandling();